// SecurDoc - This script runs in the page context (not isolated like content scripts)
// It can intercept Google Docs internal APIs

(function() {
  'use strict';

  console.log('SecurDoc: Injected script running');

  // Block the Insert Link functionality at a deeper level
  // We'll intercept common link-related commands

  // Function to disable link-related commands
  function disableLinkCommands() {
    // Try to intercept keyboard events before Google Docs processes them
    const originalAddEventListener = EventTarget.prototype.addEventListener;
    
    EventTarget.prototype.addEventListener = function(type, listener, options) {
      if (type === 'keydown' || type === 'keyup' || type === 'keypress') {
        const wrappedListener = function(e) {
          // Block Ctrl+K / Cmd+K at the deepest level
          if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K' || e.keyCode === 75)) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return false;
          }
          return listener.call(this, e);
        };
        return originalAddEventListener.call(this, type, wrappedListener, options);
      }
      return originalAddEventListener.call(this, type, listener, options);
    };
  }

  // Function to block paste operations that might contain links
  function monitorPasteOperations() {
    document.addEventListener('paste', function(e) {
      // We'll let CSS handle hiding link previews
      // This is just for monitoring
    }, true);
  }

  // Initialize all blocking mechanisms
  disableLinkCommands();
  monitorPasteOperations();

  // Continuously check for and hide link-related UI elements
  function hideUIElements() {
    // The CSS will handle most of this, but we can add additional checks
    setInterval(() => {
      // Check for any link preview popovers and hide them
      const linkPreviews = document.querySelectorAll('[role="dialog"][aria-label*="link"], [role="tooltip"][aria-label*="link"]');
      linkPreviews.forEach(preview => {
        if (preview.style.display !== 'none') {
          preview.style.display = 'none';
        }
      });
    }, 500);
  }

  hideUIElements();

  console.log('SecurDoc: All blocking mechanisms active');
})();
