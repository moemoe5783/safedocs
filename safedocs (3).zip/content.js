// SecurDoc - Content script that runs in the context of Google Docs pages
// This injects our blocking code into the page

(function() {
  'use strict';

  // Function to inject our script into the page context
  function injectScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('injected.js');
    script.onload = function() {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
  }

  // Inject as early as possible
  injectScript();

  // Monitor for dynamic content and reapply blocks
  const observer = new MutationObserver(() => {
    applyBlocks();
  });

  // Start observing once the DOM is ready
  if (document.body) {
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    });
  }

  // Apply CSS-based blocks immediately
  function applyBlocks() {
    // These will be handled by CSS, but we can add additional JavaScript blocks here
    
    // Block keyboard shortcuts for inserting links
    document.addEventListener('keydown', (e) => {
      // Block Ctrl+K / Cmd+K (Insert Link shortcut)
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        return false;
      }
    }, true);

    // Block right-click "Link" option by intercepting context menus
    document.addEventListener('contextmenu', (e) => {
      // Let the CSS handle hiding the menu items
    }, true);
  }

  applyBlocks();

  console.log('SecurDoc: Extension loaded and active');
})();
