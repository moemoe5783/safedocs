# SafeDocs Chrome Extension

A Chrome extension that enhances security and privacy in Google Docs by:
- Blocking link preview popups
- Hiding the "Insert Link" option
- Blocking keyboard shortcuts for inserting links (Ctrl+K/Cmd+K)

## Installation Instructions

1. **Download the extension files**
   - Make sure you have all the files: `manifest.json`, `content.js`, `styles.css`, and the icon files

2. **Open Chrome Extensions page**
   - Open Google Chrome
   - Navigate to `chrome://extensions/`
   - Or click the three dots menu → More Tools → Extensions

3. **Enable Developer Mode**
   - Toggle "Developer mode" switch in the top right corner

4. **Load the extension**
   - Click "Load unpacked" button
   - Navigate to the folder containing the SafeDocs extension files
   - Select the folder and click "Select Folder" (or "Open")

5. **Verify installation**
   - You should see "SafeDocs" appear in your extensions list
   - The extension is now active!

6. **Test it out**
   - Go to any Google Docs document (https://docs.google.com/document/...)
   - Try to insert a link - the option should be hidden
   - Hover over existing links - the preview should be blocked

## Features

- **Link Preview Blocking**: Prevents hover previews from appearing when you mouse over links
- **Insert Link Hidden**: Removes the insert link option from menus
- **Keyboard Shortcut Blocking**: Disables Ctrl+K/Cmd+K shortcut

## Compatibility

- Works with Google Chrome (Manifest V3)
- Compatible with other Chromium-based browsers (Edge, Brave, etc.)
- Only activates on Google Docs document pages

## Privacy

This extension:
- Does not collect any data
- Does not require any special permissions
- Only runs on Google Docs pages
- All processing happens locally in your browser

## Uninstallation

To remove the extension:
1. Go to `chrome://extensions/`
2. Find "SafeDocs"
3. Click "Remove"

## Version

Current version: 1.0.2
